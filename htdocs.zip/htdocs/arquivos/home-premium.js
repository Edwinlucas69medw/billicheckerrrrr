$(function () {
    Messenger.options = {
        extraClasses: "messenger-fixed messenger-on-top  messenger-on-right",
        theme: "flat",
        messageDefaults: {
            showCloseButton: !0
        }
    }, Messenger().post({
        message: "Hey, how are you?<br>Welcome to the Material Admin Premium template by Bootstrapious.",
        type: "success"
    })
});